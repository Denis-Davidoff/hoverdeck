"use strict";
(() => {
  // chrome-extension/background.ts
  void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {
    console.error("HoverDeck could not enable the side panel action.");
  });
})();
